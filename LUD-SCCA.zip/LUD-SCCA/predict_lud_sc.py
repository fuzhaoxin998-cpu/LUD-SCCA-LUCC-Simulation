# -*- coding: utf-8 -*-
"""
Predict with 3D-CNN and export development potential raster only.

This script is aligned with:
- model_driver_and_lu_3dcnn.py
- train_driver_and_lu_3dcnn.py

Main output:
- potential_<target_year>.tif  (K bands, per-class development potentials)

Optional:
- If --do_eval is enabled and target-year LUCC exists, print center-pixel metrics.

Notes:
- For dense full-map prediction, use --stride 1.
- The model is center-supervised, so each window writes potentials to its center pixel.
"""

import os
import argparse
import warnings
from typing import Dict, List, Optional, Tuple

import numpy as np
import rasterio
import torch
from torch.utils.data import DataLoader
from tqdm import tqdm

from model_lud_sc import build_model

os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"


# ---------------------------------------------------------------------
# Utilities
# ---------------------------------------------------------------------
def _resolve_path(p: str) -> str:
    return os.path.abspath(os.path.expanduser(p))


def _ensure_odd_patch_size(patch_size: int) -> int:
    if patch_size % 2 == 0:
        warnings.warn(f"patch_size={patch_size} is even; auto +1 to keep odd.")
        patch_size += 1
    if patch_size < 3:
        raise ValueError("patch_size must be >= 3")
    return patch_size


def _find_lucc_path(lucc_dir: str, year: int) -> str:
    cands = [
        os.path.join(lucc_dir, f"clcd_{year}_onehot.tif"),
        os.path.join(lucc_dir, f"clcd_{year}.tif"),
    ]
    for p in cands:
        if os.path.exists(p):
            return p
    raise FileNotFoundError(f"Cannot find LUCC file for year={year}: tried {cands}")


def _detect_lucc_mode_from_file(path: str) -> str:
    with rasterio.open(path) as src:
        if src.count == 6:
            return "onehot"
        if src.count == 1:
            return "index"
        raise ValueError(f"Unexpected band count={src.count} for LUCC file: {path}")


def _read_mask(path: str, expected_shape: Tuple[int, int]) -> np.ndarray:
    with rasterio.open(path) as src:
        m = src.read(1)
    if m.shape != expected_shape:
        raise ValueError(f"valid_mask shape mismatch: got {m.shape}, expected {expected_shape}")
    return (m > 0).astype(bool)


def detect_driver_names(root_dir: str, years: List[int]) -> tuple:
    names = []
    if not os.path.isdir(root_dir):
        raise FileNotFoundError(f"Driver root_dir not found: {root_dir}")
    for d in sorted(os.listdir(root_dir)):
        p = os.path.join(root_dir, d)
        if not os.path.isdir(p) or d.lower() == "lucc":
            continue
        ok = True
        for y in years:
            if not os.path.exists(os.path.join(p, f"{d}_{y}.tif")):
                ok = False
                break
        if ok:
            names.append(d)
    if not names:
        raise RuntimeError(f"No valid driver folders found under {root_dir} for years={years}")
    return tuple(names)


# ---------------------------------------------------------------------
# Metrics (optional evaluation)
# ---------------------------------------------------------------------
def per_class_f1_from_conf(conf: np.ndarray) -> Tuple[np.ndarray, float]:
    k = conf.shape[0]
    f1 = np.zeros(k, dtype=np.float64)
    for i in range(k):
        tp = conf[i, i]
        fp = conf[:, i].sum() - tp
        fn = conf[i, :].sum() - tp
        denom = 2 * tp + fp + fn
        f1[i] = (2 * tp / denom) if denom > 0 else 0.0
    return f1, float(np.mean(f1))


def change_binary_f1(y_true_change: np.ndarray, y_pred_change: np.ndarray) -> float:
    tp = np.sum((y_true_change == 1) & (y_pred_change == 1))
    fp = np.sum((y_true_change == 0) & (y_pred_change == 1))
    fn = np.sum((y_true_change == 1) & (y_pred_change == 0))
    denom = 2 * tp + fp + fn
    return float((2 * tp / denom) if denom > 0 else 0.0)


def fom_from_triplets(prev: np.ndarray, tru: np.ndarray, prd: np.ndarray) -> Dict[str, float]:
    valid = (prev >= 0) & (tru >= 0) & (prd >= 0)
    prev = prev[valid]
    tru = tru[valid]
    prd = prd[valid]
    changed = prev != tru
    pred_changed = prev != prd
    hits = np.sum(changed & pred_changed & (prd == tru))
    wrong_change = np.sum(changed & pred_changed & (prd != tru))
    misses = np.sum(changed & (~pred_changed))
    false_alarm = np.sum((~changed) & pred_changed)
    denom = hits + wrong_change + misses + false_alarm
    fom = hits / denom if denom > 0 else 0.0
    return {
        "FoM": float(fom),
        "hits": int(hits),
        "wrong_change": int(wrong_change),
        "misses": int(misses),
        "false_alarm": int(false_alarm),
    }


def eval_center_metrics(pred: np.ndarray, y_true: np.ndarray, prev: np.ndarray, num_classes: int) -> Dict[str, float]:
    valid = (y_true >= 0) & (pred >= 0)
    yv = y_true[valid].astype(np.int64)
    pv = pred[valid].astype(np.int64)
    prev_v = prev[valid].astype(np.int64)

    conf = np.zeros((num_classes, num_classes), dtype=np.int64)
    for t, p in zip(yv, pv):
        conf[t, p] += 1

    oa = float((yv == pv).mean()) if len(yv) > 0 else 0.0
    total = conf.sum()
    po = np.trace(conf) / total if total > 0 else 0.0
    pe = (conf.sum(axis=0) * conf.sum(axis=1)).sum() / (total * total) if total > 0 else 0.0
    kappa = float((po - pe) / (1 - pe)) if (1 - pe) > 1e-12 else 0.0

    per_f1, macro_f1 = per_class_f1_from_conf(conf)
    true_change = (yv != prev_v).astype(np.uint8)
    pred_change = (pv != prev_v).astype(np.uint8)
    change_f1 = change_binary_f1(true_change, pred_change)
    fom = fom_from_triplets(prev_v, yv, pv)

    metrics = {
        "OA": oa,
        "Kappa": kappa,
        "MacroF1": float(macro_f1),
        "changeF1": float(change_f1),
        "FoM": float(fom["FoM"]),
    }
    for i, v in enumerate(per_f1.tolist(), start=1):
        metrics[f"F1_class_{i}"] = float(v)
    metrics.update({
        "hits": fom["hits"],
        "wrong_change": fom["wrong_change"],
        "misses": fom["misses"],
        "false_alarm": fom["false_alarm"],
    })
    return metrics


# ---------------------------------------------------------------------
# Prediction dataset
# ---------------------------------------------------------------------
class PredictRasterDataset(torch.utils.data.Dataset):
    def __init__(
        self,
        root_dir: str,
        lucc_dir: str,
        driver_names: List[str],
        driver_input_years: List[int],
        landuse_input_years: List[int],
        base_year: int,
        num_land_classes: int,
        patch_size: int = 21,
        stride: int = 1,
        class_offset: int = 1,
        lucc_mode: str = "auto",
        valid_mask_path: Optional[str] = None,
        valid_mask_ref_year: Optional[int] = None,
        static_dir: Optional[str] = None,
        static_names: Tuple[str, ...] = ("dem", "slope", "aspect"),
        eval_target_year: Optional[int] = None,
    ):
        super().__init__()
        self.root_dir = root_dir
        self.lucc_dir = lucc_dir
        self.driver_names = list(driver_names)
        self.driver_years = list(driver_input_years)
        self.landuse_years = list(landuse_input_years)
        self.base_year = int(base_year)
        self.eval_target_year = eval_target_year
        self.num_driver_channels = len(self.driver_names)
        self.num_land_channels = int(num_land_classes)
        self.patch_size = int(patch_size)
        self.stride = int(stride)
        self.class_offset = int(class_offset)
        self.lucc_mode = lucc_mode
        self.lucc_mode_resolved = None
        self.valid_mask_path = valid_mask_path
        self.valid_mask_ref_year = valid_mask_ref_year
        self.static_dir = static_dir
        self.static_names = tuple(static_names)
        self.static_arrays: Optional[Dict[str, np.ndarray]] = None
        self.static_dim = 0

        self.driver_cache: Dict[int, Dict[str, np.ndarray]] = {}
        self.lucc_cache: Dict[int, np.ndarray] = {}

        print(f"[PredictDataset] Loading rasters into RAM | base={self.base_year} ...")
        self._load_drivers_into_memory()
        self.height, self.width = self._get_ref_shape()
        self._load_lucc_into_memory()
        self._load_static_into_memory()

        self.valid_mask = self._build_valid_mask()
        self.windows: List[Tuple[int, int]] = []
        self._build_windows()
        print(f"[PredictDataset] windows={len(self.windows)} | patch={self.patch_size} stride={self.stride}")

        self.center_base = self._compute_center_class_map(self.base_year)
        if self.eval_target_year is not None:
            self.center_target = self._compute_center_class_map(self.eval_target_year)
        else:
            self.center_target = None

    def _get_ref_shape(self) -> Tuple[int, int]:
        y0 = self.driver_years[0]
        d0 = self.driver_names[0]
        arr = self.driver_cache[y0][d0]
        return arr.shape

    def _load_drivers_into_memory(self) -> None:
        for y in sorted(set(self.driver_years)):
            self.driver_cache[y] = {}
            for d_name in self.driver_names:
                path = os.path.join(self.root_dir, d_name, f"{d_name}_{y}.tif")
                if not os.path.exists(path):
                    raise FileNotFoundError(f"Driver not found: {path}")
                with rasterio.open(path) as src:
                    data = src.read(1).astype(np.float32)
                    nodata = src.nodata
                invalid = ~np.isfinite(data) | (data < -9000)
                if nodata is not None:
                    invalid |= (data == nodata)
                data[invalid] = np.nan
                self.driver_cache[y][d_name] = data

    def _load_lucc_into_memory(self) -> None:
        years = sorted(set(self.landuse_years + [self.base_year] + ([] if self.eval_target_year is None else [self.eval_target_year])))
        if self.lucc_mode not in ("auto", "onehot", "index"):
            raise ValueError("lucc_mode must be one of {auto,onehot,index}")

        probe_path = _find_lucc_path(self.lucc_dir, years[0])
        detected = _detect_lucc_mode_from_file(probe_path)
        self.lucc_mode_resolved = detected if self.lucc_mode == "auto" else self.lucc_mode

        for y in years:
            path = _find_lucc_path(self.lucc_dir, y)
            mode_y = _detect_lucc_mode_from_file(path)
            if mode_y != self.lucc_mode_resolved:
                raise ValueError(f"LUCC mode mismatch: year={y} file_mode={mode_y} expected={self.lucc_mode_resolved}")
            with rasterio.open(path) as src:
                nodata = src.nodata
                if self.lucc_mode_resolved == "onehot":
                    arr = src.read().astype(np.float32)
                    arr[~np.isfinite(arr)] = 0.0
                    arr[arr < 0] = 0.0
                    if arr.shape[0] != self.num_land_channels:
                        raise ValueError(f"Onehot bands mismatch: got {arr.shape[0]}, expected {self.num_land_channels} ({path})")
                    self.lucc_cache[y] = arr
                else:
                    idx = src.read(1).astype(np.int16)
                    invalid = np.zeros(idx.shape, dtype=bool)
                    if nodata is not None:
                        invalid |= (idx == nodata)
                    invalid |= (idx < self.class_offset) | (idx > (self.class_offset + self.num_land_channels - 1))
                    idx[invalid] = -1
                    ok = idx >= 0
                    idx[ok] = idx[ok] - self.class_offset
                    self.lucc_cache[y] = idx

    def _load_static_into_memory(self) -> None:
        if not self.static_dir:
            self.static_arrays = None
            self.static_dim = 0
            return
        arrays: Dict[str, np.ndarray] = {}
        for name in self.static_names:
            path = os.path.join(self.static_dir, f"{name}.tif")
            if not os.path.exists(path):
                raise FileNotFoundError(f"Static raster not found: {path}")
            with rasterio.open(path) as src:
                arr = src.read(1).astype(np.float32)
                nodata = src.nodata
            invalid = ~np.isfinite(arr)
            if nodata is not None:
                invalid |= (arr == nodata)
            arr[invalid] = np.nan
            arrays[name] = arr
        if "aspect" in arrays:
            asp = arrays["aspect"]
            rad = np.deg2rad(asp)
            arrays["aspect_sin"] = np.sin(rad).astype(np.float32)
            arrays["aspect_cos"] = np.cos(rad).astype(np.float32)
            arrays.pop("aspect", None)
        self.static_arrays = arrays
        self.static_dim = len(self._static_feature_order())

    def _static_feature_order(self) -> List[str]:
        if not self.static_arrays:
            return []
        order = []
        for k in ("dem", "slope", "aspect_sin", "aspect_cos"):
            if k in self.static_arrays:
                order.append(k)
        for k in sorted(self.static_arrays.keys()):
            if k not in order:
                order.append(k)
        return order

    def _build_valid_mask(self) -> np.ndarray:
        if self.valid_mask_path:
            return _read_mask(self.valid_mask_path, (self.height, self.width))
        if self.valid_mask_ref_year is not None:
            y = int(self.valid_mask_ref_year)
            if self.lucc_mode_resolved == "onehot":
                return np.sum(self.lucc_cache[y], axis=0) > 0
            return self.lucc_cache[y] >= 0
        ref_year = self.landuse_years[-1]
        if self.lucc_mode_resolved == "onehot":
            return np.sum(self.lucc_cache[ref_year], axis=0) > 0
        return self.lucc_cache[ref_year] >= 0

    def _build_windows(self) -> None:
        ps = self.patch_size
        half = ps // 2
        for top in range(0, self.height - ps + 1, self.stride):
            for left in range(0, self.width - ps + 1, self.stride):
                ct, cl = top + half, left + half
                if self.valid_mask[ct, cl]:
                    self.windows.append((top, left))

    def _get_lucc_patch_onehot(self, year: int, top: int, left: int) -> np.ndarray:
        h = self.patch_size
        if self.lucc_mode_resolved == "onehot":
            return self.lucc_cache[year][:, top:top + h, left:left + h]
        idx_patch = self.lucc_cache[year][top:top + h, left:left + h]
        out = np.zeros((self.num_land_channels, h, h), dtype=np.float32)
        for c in range(self.num_land_channels):
            out[c] = (idx_patch == c).astype(np.float32)
        return out

    def _get_lucc_center_class(self, year: int, top: int, left: int) -> int:
        half = self.patch_size // 2
        r, c = top + half, left + half
        if self.lucc_mode_resolved == "onehot":
            vec = self.lucc_cache[year][:, r, c]
            if np.sum(vec) <= 0:
                return -1
            return int(np.argmax(vec))
        val = int(self.lucc_cache[year][r, c])
        return val if val >= 0 else -1

    def _get_static_patch(self, top: int, left: int) -> Optional[np.ndarray]:
        """
        Return static patch with shape (C_static, patch_size, patch_size).
        """
        if not self.static_arrays or self.static_dim <= 0:
            return None

        h = self.patch_size
        feats = []
        for name in self._static_feature_order():
            arr = self.static_arrays[name][top:top + h, left:left + h].astype(np.float32)
            arr = np.nan_to_num(arr, nan=0.0, posinf=0.0, neginf=0.0)
            feats.append(arr)

        if not feats:
            return None
        return np.stack(feats, axis=0).astype(np.float32)

    def _compute_center_class_map(self, year: int) -> np.ndarray:
        arr = np.full((len(self.windows),), -1, dtype=np.int16)
        for i, (top, left) in enumerate(self.windows):
            arr[i] = self._get_lucc_center_class(year, top, left)
        return arr

    def __len__(self) -> int:
        return len(self.windows)

    def __getitem__(self, idx: int):
        top, left = self.windows[idx]

        # drivers_seq: (C_drv, T, H, W)
        drv_list = []
        for y in self.driver_years:
            chans = []
            for d_name in self.driver_names:
                arr = self.driver_cache[y][d_name][top:top + self.patch_size, left:left + self.patch_size]
                arr = np.nan_to_num(arr, nan=0.0, posinf=0.0, neginf=0.0).astype(np.float32)
                chans.append(arr)
            drv_y = np.stack(chans, axis=0)  # (C_drv, H, W)
            drv_list.append(drv_y)
        drivers_seq = np.stack(drv_list, axis=1).astype(np.float32)  # (C_drv, T, H, W)

        # landuse_seq: (C_lu, T, H, W)
        lu_list = []
        for y in self.landuse_years:
            lu_patch = self._get_lucc_patch_onehot(y, top, left).astype(np.float32)
            lu_list.append(lu_patch)
        landuse_seq = np.stack(lu_list, axis=1).astype(np.float32)  # (C_lu, T, H, W)

        item = {
            "drivers_seq": torch.from_numpy(drivers_seq),
            "landuse_seq": torch.from_numpy(landuse_seq),
            "center_base": torch.tensor(self._get_lucc_center_class(self.base_year, top, left), dtype=torch.long),
            "top": torch.tensor(top, dtype=torch.long),
            "left": torch.tensor(left, dtype=torch.long),
        }

        if self.eval_target_year is not None:
            item["center_target"] = torch.tensor(
                self._get_lucc_center_class(self.eval_target_year, top, left),
                dtype=torch.long
            )

        static_patch = self._get_static_patch(top, left)
        if static_patch is not None:
            item["static_patch"] = torch.from_numpy(static_patch)

        return item


# ---------------------------------------------------------------------
# Main prediction
# ---------------------------------------------------------------------
@torch.no_grad()
def main():
    parser = argparse.ArgumentParser()

    # I/O
    parser.add_argument("--root_dir", type=str, default="../data/drivers/dynamic")
    parser.add_argument("--lucc_dir", type=str, default="../data/lucc")
    parser.add_argument("--static_dir", type=str, default="../data/drivers/static")
    parser.add_argument("--ckpt", type=str, default="ckpts/best_model_driver_and_lu_3dcnn.pth")
    parser.add_argument("--out_dir", type=str, default="pred_outputs_driver_and_lu_3dcnn")

    # Prediction years
    parser.add_argument("--landuse_input_years", type=int, nargs='+', default=[2005, 2010, 2015])
    parser.add_argument("--driver_input_years", type=int, nargs='+', default=[2010, 2015, 2020])
    parser.add_argument("--base_year", type=int, default=2015)
    parser.add_argument("--target_year", type=int, default=2020)

    # Data config
    parser.add_argument("--num_land_classes", type=int, default=6)
    parser.add_argument("--lucc_mode", type=str, choices=["auto", "onehot", "index"], default="index")
    parser.add_argument("--class_offset", type=int, default=1)
    parser.add_argument("--patch_size", type=int, default=11)
    parser.add_argument("--stride", type=int, default=1)
    parser.add_argument("--valid_mask", type=str, default="../data/lucc/mask_valid.tif")
    parser.add_argument("--static_names", type=str, nargs='+', default=["dem", "slope", "aspect"])

    # Inference
    parser.add_argument("--batch_size", type=int, default=256)
    parser.add_argument("--num_workers", type=int, default=0)
    parser.add_argument("--embed_dim", type=int, default=128)
    parser.add_argument("--dropout_rate", type=float, default=0.25)

    # Optional evaluation
    parser.add_argument("--do_eval", action="store_true")

    args = parser.parse_args()

    args.root_dir = _resolve_path(args.root_dir)
    args.lucc_dir = _resolve_path(args.lucc_dir)
    args.static_dir = _resolve_path(args.static_dir) if args.static_dir else None
    args.ckpt = _resolve_path(args.ckpt)
    args.out_dir = _resolve_path(args.out_dir)
    os.makedirs(args.out_dir, exist_ok=True)
    if args.valid_mask:
        args.valid_mask = _resolve_path(args.valid_mask)

    torch.set_grad_enabled(False)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    args.patch_size = _ensure_odd_patch_size(args.patch_size)

    # ---- load checkpoint first, then restore training-side config before building dataset/model ----
    ckpt = torch.load(args.ckpt, map_location=device)

    if not isinstance(ckpt, dict) or "model_state" not in ckpt:
        raise ValueError(f"[Predict] Invalid checkpoint format: {args.ckpt}")

    train_args = ckpt.get("args", {}) if isinstance(ckpt, dict) else {}

    # recover training-side hyper-parameters / data-side config as much as possible
    embed_dim = int(train_args.get("embed_dim", args.embed_dim))
    dropout_rate = float(train_args.get("dropout_rate", args.dropout_rate))
    patch_size = int(train_args.get("patch_size", args.patch_size))
    patch_size = _ensure_odd_patch_size(patch_size)

    num_land_classes = int(ckpt.get("num_land_classes", args.num_land_classes))
    static_dim = int(ckpt.get("static_dim", 0))

    # restore static feature order from training args when available
    static_names = tuple(train_args.get("static_names", args.static_names))

    # driver names: use checkpoint order as authoritative if present
    ckpt_driver_names = ckpt.get("driver_names", None)
    if ckpt_driver_names is not None:
        driver_names = tuple(ckpt_driver_names)
        # verify required driver rasters exist for all prediction years
        missing = []
        for d in driver_names:
            for y in args.driver_input_years:
                p = os.path.join(args.root_dir, d, f"{d}_{y}.tif")
                if not os.path.exists(p):
                    missing.append(p)
        if missing:
            raise FileNotFoundError(
                "[Predict] Some driver rasters required by checkpoint are missing:\n" +
                "\n".join(missing[:20])
            )
        print(f"[Predict] driver_names restored from ckpt: {driver_names}")
    else:
        all_driver_years = sorted(set(args.driver_input_years))
        driver_names = detect_driver_names(args.root_dir, years=all_driver_years)
        if not driver_names:
            raise RuntimeError("No dynamic drivers detected for prediction.")
        print(f"[Predict] Drivers(dynamic): {driver_names}")

    print(
        f"[Predict] Model/data args restored from ckpt | "
        f"embed_dim={embed_dim}, dropout_rate={dropout_rate}, "
        f"patch_size={patch_size}, static_names={list(static_names)}"
    )

    eval_target_year = None
    if args.do_eval:
        try:
            _find_lucc_path(args.lucc_dir, args.target_year)
            eval_target_year = args.target_year
        except FileNotFoundError:
            print(f"[Predict] target_year={args.target_year} LUCC not found; disable evaluation.")
            eval_target_year = None

    ds = PredictRasterDataset(
        root_dir=args.root_dir,
        lucc_dir=args.lucc_dir,
        driver_names=list(driver_names),
        driver_input_years=args.driver_input_years,
        landuse_input_years=args.landuse_input_years,
        base_year=args.base_year,
        num_land_classes=num_land_classes,
        patch_size=patch_size,
        stride=args.stride,
        class_offset=args.class_offset,
        lucc_mode=args.lucc_mode,
        valid_mask_path=args.valid_mask,
        valid_mask_ref_year=args.base_year if args.valid_mask is None else None,
        static_dir=args.static_dir,
        static_names=static_names,
        eval_target_year=eval_target_year,
    )

    loader = DataLoader(
        ds,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=args.num_workers,
        pin_memory=True
    )

    # if static features were used in training, prediction-side dataset must provide the same dim
    ckpt_num_static_channels = int(ckpt.get("num_static_channels", static_dim))
    if ckpt_num_static_channels != int(ds.static_dim):
        raise ValueError(
            f"[Predict] num_static_channels mismatch: ckpt={ckpt_num_static_channels}, dataset={ds.static_dim}. "
            f"Please check --static_dir / --static_names."
        )

    ckpt_num_static_channels = int(ckpt.get("num_static_channels", static_dim))

    model = build_model(
        num_driver_channels=len(driver_names),
        num_land_channels=num_land_classes,
        num_classes=num_land_classes,
        dropout_rate=dropout_rate,
        static_dim=static_dim,  # 保留兼容
        num_static_channels=ckpt_num_static_channels,  # 新增
        static_feat_dim=32,
        embed_dim=embed_dim,
    ).to(device)

    model.load_state_dict(ckpt["model_state"], strict=True)
    model.eval()

    half = patch_size // 2

    # Reference profile for writing raster
    try:
        ref_path = _find_lucc_path(args.lucc_dir, args.base_year)
    except FileNotFoundError:
        d0 = driver_names[0]
        ref_path = os.path.join(args.root_dir, d0, f"{d0}_{args.driver_input_years[-1]}.tif")

    with rasterio.open(ref_path) as src:
        ref_profile = src.profile.copy()
        H, W = src.height, src.width

    pot_cube = np.zeros((num_land_classes, H, W), dtype=np.float32)

    pred_all, y_all, prev_all = [], [], []

    for batch in tqdm(loader, desc="Predicting potentials"):
        drivers = batch["drivers_seq"].to(device, non_blocking=True)
        landuse = batch["landuse_seq"].to(device, non_blocking=True)
        static_patch = batch.get("static_patch", None)
        if static_patch is not None:
            static_patch = static_patch.to(device, non_blocking=True)

        out = model(
            drivers,
            landuse,
            static_patch=static_patch,
            return_attn=False,
        )
        potential = out["potential"].squeeze(-1).squeeze(-1).detach().cpu().numpy().astype(np.float32)  # (B,K)

        tops = batch["top"].cpu().numpy().astype(np.int32)
        lefts = batch["left"].cpu().numpy().astype(np.int32)
        prev = batch["center_base"].cpu().numpy().astype(np.int16)

        for i in range(len(tops)):
            r = int(tops[i] + half)
            c = int(lefts[i] + half)
            pot_cube[:, r, c] = potential[i]

        if eval_target_year is not None and "center_target" in batch:
            pred = np.argmax(potential, axis=1).astype(np.int16)
            y = batch["center_target"].cpu().numpy().astype(np.int16)
            pred_all.append(pred)
            y_all.append(y)
            prev_all.append(prev)

    # write potential raster only
    out_path = os.path.join(args.out_dir, f"potential_{args.target_year}.tif")
    profile = ref_profile.copy()
    profile.update(
        dtype="float32",
        count=num_land_classes,
        compress="lzw",
        nodata=0.0,
    )
    with rasterio.open(out_path, "w", **profile) as dst:
        dst.write(pot_cube)
    print(f"[Predict] saved development potential raster -> {out_path}")

    # optional evaluation
    if eval_target_year is not None and pred_all:
        pred_all = np.concatenate(pred_all)
        y_all = np.concatenate(y_all)
        prev_all = np.concatenate(prev_all)
        metrics = eval_center_metrics(pred_all, y_all, prev_all, num_land_classes)
        print("\n========== Center-pixel Evaluation ==========")
        for k, v in metrics.items():
            if isinstance(v, float):
                print(f"{k}: {v:.4f}")
            else:
                print(f"{k}: {v}")
        with open(os.path.join(args.out_dir, f"metrics_{args.target_year}.txt"), "w", encoding="utf-8") as f:
            for k, v in metrics.items():
                f.write(f"{k}: {v}\n")


if __name__ == "__main__":
    main()