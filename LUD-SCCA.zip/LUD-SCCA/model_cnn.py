# -*- coding: utf-8 -*-
"""
Joint non-temporal 2D-CNN baseline for development potential prediction.

Design goal:
- jointly use land-use patch and driver patch from a single time setting
- no temporal history input
- no explicit temporal convolution
- optional static patch branch
- center-pixel supervision only

Expected dynamic input:
    dynamic_patch: (B, C_dyn, H, W)

where:
    C_dyn = C_lu + C_drv

Optional static input:
    static_patch: (B, C_static, H, W)

Outputs:
    pot_logits: (B, K, 1, 1)
    potential : (B, K, 1, 1)
"""

from __future__ import annotations

from typing import Dict, Optional

import torch
import torch.nn as nn


class Conv2DBlock(nn.Module):
    def __init__(self, in_ch: int, out_ch: int, drop: float = 0.08):
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv2d(in_ch, out_ch, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True),
            nn.Dropout2d(drop),

            nn.Conv2d(out_ch, out_ch, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.block(x)


class SpatialJointBranch(nn.Module):
    """
    2D spatial encoder over single-time joint LU+Driver channels.
    No explicit temporal modeling is used.
    """
    def __init__(self, in_ch: int, embed_dim: int = 128, drop: float = 0.08):
        super().__init__()
        self.stem = Conv2DBlock(in_ch, 32, drop=drop)
        self.pool = nn.MaxPool2d(kernel_size=2, stride=2)
        self.block2 = Conv2DBlock(32, 64, drop=drop)
        self.block3 = Conv2DBlock(64, embed_dim, drop=drop)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.stem(x)
        x = self.pool(x)
        x = self.block2(x)
        x = self.block3(x)
        return x


class AvgMaxPoolFuse(nn.Module):
    def __init__(self, in_dim: int, out_dim: int, drop: float = 0.1):
        super().__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d((1, 1))
        self.max_pool = nn.AdaptiveMaxPool2d((1, 1))
        self.fuse = nn.Sequential(
            nn.Linear(2 * in_dim, out_dim),
            nn.LayerNorm(out_dim),
            nn.ReLU(inplace=True),
            nn.Dropout(drop),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        z_avg = self.avg_pool(x).flatten(1)
        z_max = self.max_pool(x).flatten(1)
        z = torch.cat([z_avg, z_max], dim=1)
        return self.fuse(z)


class StaticSpatialBranch(nn.Module):
    def __init__(self, in_ch: int, out_dim: int = 32, drop: float = 0.25):
        super().__init__()
        hidden1 = max(16, out_dim)
        hidden2 = max(32, out_dim)

        self.encoder = nn.Sequential(
            nn.Conv2d(in_ch, hidden1, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(hidden1),
            nn.ReLU(inplace=True),

            nn.Conv2d(hidden1, hidden2, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(hidden2),
            nn.ReLU(inplace=True),
        )

        self.pool_fuse = AvgMaxPoolFuse(
            in_dim=hidden2,
            out_dim=out_dim,
            drop=drop,
        )

    def forward(self, static_patch: torch.Tensor) -> torch.Tensor:
        feat = self.encoder(static_patch)
        z_static = self.pool_fuse(feat)
        return z_static


class PotentialHead(nn.Module):
    def __init__(self, dyn_dim: int, num_classes: int, static_feat_dim: int = 0, drop: float = 0.25):
        super().__init__()
        self.static_feat_dim = int(static_feat_dim)
        fusion_in = dyn_dim + self.static_feat_dim

        self.cls = nn.Sequential(
            nn.Linear(fusion_in, 128),
            nn.ReLU(inplace=True),
            nn.Dropout(drop),
            nn.Linear(128, num_classes),
        )

    def forward(self, z_dyn: torch.Tensor, z_static: Optional[torch.Tensor] = None) -> torch.Tensor:
        if self.static_feat_dim > 0:
            if z_static is None:
                z_static = torch.zeros(
                    (z_dyn.shape[0], self.static_feat_dim),
                    device=z_dyn.device,
                    dtype=z_dyn.dtype,
                )
            z = torch.cat([z_dyn, z_static], dim=1)
        else:
            z = z_dyn
        return self.cls(z)


class Joint2DPotentialNet(nn.Module):
    """
    Joint non-temporal 2D-CNN baseline:
    - single-time LU and single-time drivers are concatenated on channel dimension
    - 2D convolution only
    - no temporal history input
    """
    def __init__(
        self,
        num_dynamic_channels: int,
        num_classes: int,
        embed_dim: int = 128,
        dropout_rate: float = 0.25,
        num_static_channels: int = 0,
        static_feat_dim: int = 32,
    ):
        super().__init__()
        self.num_classes = int(num_classes)
        self.num_static_channels = int(num_static_channels)
        self.static_feat_dim = int(static_feat_dim)
        self.use_static_patch = self.num_static_channels > 0

        branch_drop = min(0.08, dropout_rate)

        self.dynamic_branch = SpatialJointBranch(
            num_dynamic_channels,
            embed_dim=embed_dim,
            drop=branch_drop,
        )

        self.dynamic_pool_fuse = AvgMaxPoolFuse(
            in_dim=embed_dim,
            out_dim=embed_dim,
            drop=dropout_rate * 0.5,
        )

        if self.use_static_patch:
            self.static_branch = StaticSpatialBranch(
                in_ch=self.num_static_channels,
                out_dim=self.static_feat_dim,
                drop=dropout_rate * 0.5,
            )
            head_static_dim = self.static_feat_dim
        else:
            self.static_branch = None
            head_static_dim = 0

        self.head = PotentialHead(
            dyn_dim=embed_dim,
            num_classes=num_classes,
            static_feat_dim=head_static_dim,
            drop=dropout_rate,
        )

    def forward(
        self,
        dynamic_patch: torch.Tensor,
        static_patch: Optional[torch.Tensor] = None,
    ) -> Dict[str, torch.Tensor]:
        feat_dyn = self.dynamic_branch(dynamic_patch)
        z_dyn = self.dynamic_pool_fuse(feat_dyn)

        z_static = None
        if self.use_static_patch:
            if static_patch is None:
                raise ValueError("static_patch is required when num_static_channels > 0.")
            z_static = self.static_branch(static_patch)

        logits = self.head(z_dyn, z_static)
        potential = torch.softmax(logits, dim=1)

        return {
            "pot_logits": logits.unsqueeze(-1).unsqueeze(-1),
            "potential": potential.unsqueeze(-1).unsqueeze(-1),
        }


def build_model(
    num_dynamic_channels: int,
    num_classes: int,
    dropout_rate: float = 0.25,
    num_static_channels: int = 0,
    static_feat_dim: int = 32,
    embed_dim: int = 128,
):
    print(
        "Building joint non-temporal 2D-CNN baseline | "
        "(single-time LU + single-time drivers + optional static patch)."
    )
    return Joint2DPotentialNet(
        num_dynamic_channels=num_dynamic_channels,
        num_classes=num_classes,
        embed_dim=embed_dim,
        dropout_rate=dropout_rate,
        num_static_channels=num_static_channels,
        static_feat_dim=static_feat_dim,
    )