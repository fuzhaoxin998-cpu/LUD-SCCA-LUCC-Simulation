# -*- coding: utf-8 -*-
"""
LU-only 3D-CNN baseline for development potential prediction.

This file keeps only the LU branch related components.

Core components:
- TemporalLUBranch backbone
- ChannelWiseTemporalPool
- avg+max spatial pooling
- optional StaticSpatialBranch
- PotentialHead

Expected inputs:
- landuse_seq: (B, C_lu, T, H, W)
- static_patch: Optional[(B, C_static, H, W)]

Outputs:
- pot_logits: (B, K, 1, 1)
- potential:  (B, K, 1, 1)
- alpha:      temporal summary
- alpha_lu:   LU branch temporal diagnostic
- alpha_lu_pool: LU temporal pooling weights
"""

from typing import Optional, Dict

import torch
import torch.nn as nn


class Conv3DBlock(nn.Module):
    def __init__(self, in_ch: int, out_ch: int, k=3, s=1, p=1, drop: float = 0.25):
        super().__init__()
        layers = [
            nn.Conv3d(in_ch, out_ch, kernel_size=k, stride=s, padding=p, bias=False),
            nn.BatchNorm3d(out_ch),
            nn.ReLU(inplace=True),
        ]
        if drop and drop > 0:
            layers.append(nn.Dropout3d(drop))
        self.block = nn.Sequential(*layers)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.block(x)


class TemporalLUBranch(nn.Module):
    def __init__(self, in_ch: int, embed_dim: int = 128, drop: float = 0.25):
        super().__init__()
        self.stem = Conv3DBlock(in_ch, 32, drop=drop)
        self.pool = nn.MaxPool3d(kernel_size=(1, 2, 2), stride=(1, 2, 2))
        self.block2 = Conv3DBlock(32, 64, drop=drop)
        self.block3 = Conv3DBlock(64, embed_dim, drop=drop)

    def forward_stem(self, x: torch.Tensor) -> torch.Tensor:
        x = self.stem(x)
        x = self.pool(x)
        return x

    def forward_block2(self, x: torch.Tensor) -> torch.Tensor:
        return self.block2(x)

    def forward_block3(self, x: torch.Tensor) -> torch.Tensor:
        return self.block3(x)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.forward_stem(x)
        x = self.forward_block2(x)
        x = self.forward_block3(x)
        return x


class ChannelWiseTemporalPool(nn.Module):
    """
    Channel-aware temporal scorer / pooling.

    Input:
        x: (B, D, T, H, W)

    Output:
        alpha: (B, D, T)
        x_agg: (B, D, H, W), alpha
    """

    def __init__(self, dim: int = 128, hidden: int = 64, drop: float = 0.25):
        super().__init__()
        self.proj1 = nn.Conv3d(dim, hidden, kernel_size=1, bias=True)
        self.act = nn.ReLU(inplace=True)
        self.drop = nn.Dropout(drop)
        self.proj2 = nn.Conv3d(hidden, dim, kernel_size=1, bias=True)

    def compute_alpha(self, x: torch.Tensor) -> torch.Tensor:
        score_in = x.mean(dim=(-1, -2), keepdim=True)  # (B, D, T, 1, 1)
        score = self.proj2(self.drop(self.act(self.proj1(score_in)))).squeeze(-1).squeeze(-1)  # (B, D, T)
        alpha = torch.softmax(score, dim=2)
        return alpha

    def aggregate(self, x: torch.Tensor, alpha: torch.Tensor) -> torch.Tensor:
        return torch.sum(x * alpha[:, :, :, None, None], dim=2)

    def forward(self, x: torch.Tensor, return_alpha: bool = False):
        alpha = self.compute_alpha(x)
        x_agg = self.aggregate(x, alpha)
        if return_alpha:
            return x_agg, alpha
        return x_agg


class AvgMaxPoolFuse(nn.Module):
    """
    Parallel avg+max pooling, then fuse back to out_dim.

    Input:
        x: (B, C, H, W)

    Output:
        z: (B, out_dim)
    """
    def __init__(self, in_dim: int, out_dim: int, drop: float = 0.1):
        super().__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d((1, 1))
        self.max_pool = nn.AdaptiveMaxPool2d((1, 1))
        self.fuse = nn.Sequential(
            nn.Linear(2 * in_dim, out_dim),
            nn.LayerNorm(out_dim),
            nn.ReLU(inplace=True),
            nn.Dropout(drop),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        z_avg = self.avg_pool(x).flatten(1)
        z_max = self.max_pool(x).flatten(1)
        z = torch.cat([z_avg, z_max], dim=1)
        return self.fuse(z)


class StaticSpatialBranch(nn.Module):
    """
    Static patch branch aligned with the single-stream stacked 3D-CNN.

    Design:
    - 2-layer 2D CNN encoder
    - parallel avg+max pooling fusion via AvgMaxPoolFuse
    """

    def __init__(self, in_ch: int, out_dim: int = 32, drop: float = 0.25):
        super().__init__()
        hidden1 = max(16, out_dim)
        hidden2 = max(32, out_dim)

        self.encoder = nn.Sequential(
            nn.Conv2d(in_ch, hidden1, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(hidden1),
            nn.ReLU(inplace=True),

            nn.Conv2d(hidden1, hidden2, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(hidden2),
            nn.ReLU(inplace=True),
        )

        self.pool_fuse = AvgMaxPoolFuse(
            in_dim=hidden2,
            out_dim=out_dim,
            drop=drop,
        )

    def forward(self, static_patch: torch.Tensor) -> torch.Tensor:
        feat = self.encoder(static_patch)   # (B, hidden2, H, W)
        z_static = self.pool_fuse(feat)     # (B, out_dim)
        return z_static


class PotentialHead(nn.Module):
    """
    Final classifier head.
    """

    def __init__(self, dyn_dim: int, num_classes: int, static_feat_dim: int = 0, drop: float = 0.25):
        super().__init__()
        self.static_feat_dim = int(static_feat_dim)
        fusion_in = dyn_dim + self.static_feat_dim

        self.cls = nn.Sequential(
            nn.Linear(fusion_in, 128),
            nn.ReLU(inplace=True),
            nn.Dropout(drop),
            nn.Linear(128, num_classes),
        )

    def forward(
        self,
        z_dyn: torch.Tensor,
        z_static: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        if self.static_feat_dim > 0:
            if z_static is None:
                z_static = torch.zeros(
                    (z_dyn.shape[0], self.static_feat_dim),
                    device=z_dyn.device,
                    dtype=z_dyn.dtype,
                )
            z = torch.cat([z_dyn, z_static], dim=1)
        else:
            z = z_dyn
        return self.cls(z)


class LUOnlyPotentialNet(nn.Module):
    """
    LU-only 3D-CNN baseline.
    """

    def __init__(
        self,
        num_land_channels: int,
        num_classes: int,
        embed_dim: int = 128,
        dropout_rate: float = 0.25,
        num_static_channels: int = 0,
        static_feat_dim: int = 32,
    ):
        super().__init__()
        self.num_classes = int(num_classes)
        self.num_static_channels = int(num_static_channels)
        self.static_feat_dim = int(static_feat_dim)
        self.use_static_patch = self.num_static_channels > 0

        branch_drop = min(0.08, dropout_rate)

        self.lu_branch = TemporalLUBranch(
            num_land_channels,
            embed_dim=embed_dim,
            drop=branch_drop,
        )

        self.alpha_probe_lu = ChannelWiseTemporalPool(
            dim=embed_dim,
            hidden=max(32, embed_dim // 2),
            drop=dropout_rate * 0.5,
        )
        self.temporal_pool_single = ChannelWiseTemporalPool(
            dim=embed_dim,
            hidden=max(32, embed_dim // 2),
            drop=dropout_rate * 0.5,
        )

        self.avg_pool2d = nn.AdaptiveAvgPool2d((1, 1))
        self.max_pool2d = nn.AdaptiveMaxPool2d((1, 1))
        self.single_pool_fuse = nn.Sequential(
            nn.Linear(2 * embed_dim, embed_dim),
            nn.LayerNorm(embed_dim),
            nn.ReLU(inplace=True),
            nn.Dropout(dropout_rate * 0.5),
        )

        if self.use_static_patch:
            self.static_branch = StaticSpatialBranch(
                in_ch=self.num_static_channels,
                out_dim=self.static_feat_dim,
                drop=dropout_rate * 0.5,
            )
            head_static_dim = self.static_feat_dim
        else:
            self.static_branch = None
            head_static_dim = 0

        self.head = PotentialHead(
            dyn_dim=embed_dim,
            num_classes=num_classes,
            static_feat_dim=head_static_dim,
            drop=dropout_rate,
        )

    @staticmethod
    def _mean_alpha(alpha: torch.Tensor) -> torch.Tensor:
        return alpha.mean(dim=1)

    def forward(
        self,
        landuse_seq: torch.Tensor,
        static_patch: Optional[torch.Tensor] = None,
        return_attn: bool = False,
    ) -> Dict[str, torch.Tensor]:

        f_lu_3d = self.lu_branch(landuse_seq)
        alpha_lu = self.alpha_probe_lu.compute_alpha(f_lu_3d)
        f_lu_2d, alpha_lu_pool = self.temporal_pool_single(f_lu_3d, return_alpha=True)

        z_avg = self.avg_pool2d(f_lu_2d).flatten(1)
        z_max = self.max_pool2d(f_lu_2d).flatten(1)
        z_dyn = self.single_pool_fuse(torch.cat([z_avg, z_max], dim=1))
        alpha_summary = self._mean_alpha(alpha_lu_pool)

        z_static = None
        if self.use_static_patch:
            if static_patch is None:
                raise ValueError("static_patch is required when num_static_channels > 0.")
            z_static = self.static_branch(static_patch)

        logits = self.head(z_dyn, z_static)
        potential = torch.softmax(logits, dim=1)

        out = {
            "pot_logits": logits.unsqueeze(-1).unsqueeze(-1),
            "potential": potential.unsqueeze(-1).unsqueeze(-1),
        }

        if return_attn:
            out["alpha"] = alpha_summary
            out["alpha_lu"] = alpha_lu
            out["alpha_lu_pool"] = alpha_lu_pool

        return out


def build_model(
    num_land_channels: int,
    num_classes: int,
    dropout_rate: float = 0.2,
    num_static_channels: int = 0,
    static_feat_dim: int = 32,
    embed_dim: int = 128,
):
    print(
        "Building LU-only 3D-CNN baseline | "
        "(TemporalLUBranch + temporal pooling + avg/max spatial pooling + potential head)."
    )
    return LUOnlyPotentialNet(
        num_land_channels=num_land_channels,
        num_classes=num_classes,
        embed_dim=embed_dim,
        dropout_rate=dropout_rate,
        num_static_channels=num_static_channels,
        static_feat_dim=static_feat_dim,
    )