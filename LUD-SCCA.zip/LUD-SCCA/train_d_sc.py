# -*- coding: utf-8 -*-
"""
Train Driver-only 3D-CNN for development potential prediction.

Compared with the original training script, this version intentionally simplifies the model target:
- keep / gate / class multi-head outputs are removed
- the model directly predicts per-class development potentials
- center-pixel supervision only

This script is self-contained and follows the same data protocol as the existing project:
- Scheme A two tasks
- spatial block split
- Driver patch sequence + optional static patch input
- LU target/base maps are used only for supervision and change diagnostics
"""

import os
import argparse
import warnings
import random
from typing import Dict, List, Optional, Tuple

import numpy as np
import rasterio
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader, WeightedRandomSampler, Subset, ConcatDataset
from tqdm import tqdm
import json

from model_d_sc import build_model

os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"


# ------------------------------------------------------------------------
# Utils
# ------------------------------------------------------------------------
def _resolve_path(p: str) -> str:
    return os.path.abspath(os.path.expanduser(p))


def set_global_reproducibility(seed: int):
    os.environ["PYTHONHASHSEED"] = str(seed)

    random.seed(seed)
    np.random.seed(seed)

    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)

    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def seed_worker(worker_id: int):
    worker_seed = torch.initial_seed() % 2**32
    np.random.seed(worker_seed)
    random.seed(worker_seed)


def _ensure_odd_patch_size(patch_size: int) -> int:
    if patch_size % 2 == 0:
        warnings.warn(f"patch_size={patch_size} is even; auto +1 to keep odd.")
        patch_size += 1
    if patch_size < 3:
        raise ValueError("patch_size must be >= 3")
    return patch_size


def _find_lucc_path(lucc_dir: str, year: int) -> str:
    cands = [
        os.path.join(lucc_dir, f"clcd_{year}_onehot.tif"),
        os.path.join(lucc_dir, f"clcd_{year}.tif"),
    ]
    for p in cands:
        if os.path.exists(p):
            return p
    raise FileNotFoundError(f"Cannot find LUCC file for year={year}: tried {cands}")


def _detect_lucc_mode_from_file(path: str) -> str:
    with rasterio.open(path) as src:
        if src.count == 6:
            return "onehot"
        if src.count == 1:
            return "index"
        raise ValueError(f"Unexpected band count={src.count} for LUCC file: {path}")


def _read_mask(path: str, expected_shape: Tuple[int, int]) -> np.ndarray:
    with rasterio.open(path) as src:
        m = src.read(1)
    if m.shape != expected_shape:
        raise ValueError(f"valid_mask shape mismatch: got {m.shape}, expected {expected_shape}")
    return (m > 0).astype(bool)


def detect_driver_names(root_dir: str, years: List[int]) -> tuple:
    names = []
    if not os.path.isdir(root_dir):
        raise FileNotFoundError(f"Driver root_dir not found: {root_dir}")
    for d in sorted(os.listdir(root_dir)):
        p = os.path.join(root_dir, d)
        if not os.path.isdir(p) or d.lower() == "lucc":
            continue
        ok = True
        for y in years:
            if not os.path.exists(os.path.join(p, f"{d}_{y}.tif")):
                ok = False
                break
        if ok:
            names.append(d)
    if not names:
        raise RuntimeError(f"No valid driver folders found under {root_dir} for years={years}")
    return tuple(names)


def _load_shared_block_split(split_json_path: str) -> dict:
    with open(split_json_path, "r", encoding="utf-8") as f:
        obj = json.load(f)
    required = ["block_size_px", "front_train_blocks", "front_val_blocks", "front_test_blocks"]
    for k in required:
        if k not in obj:
            raise ValueError(f"Missing key in split json: {k}")
    return obj


def _split_indices_from_shared_blocks_windows(
    windows,
    patch_size: int,
    split_obj: dict,
):
    block_size_px = int(split_obj["block_size_px"])
    train_blocks = set(tuple(x) for x in split_obj["front_train_blocks"])
    val_blocks = set(tuple(x) for x in split_obj["front_val_blocks"])
    test_blocks = set(tuple(x) for x in split_obj["front_test_blocks"])

    half = patch_size // 2
    train_idx, val_idx, test_idx = [], [], []

    for i, (top, left) in enumerate(windows):
        ct, cl = top + half, left + half
        bid = (ct // block_size_px, cl // block_size_px)
        if bid in train_blocks:
            train_idx.append(i)
        elif bid in val_blocks:
            val_idx.append(i)
        elif bid in test_blocks:
            test_idx.append(i)

    return train_idx, val_idx, test_idx


def _compute_adaptive_sample_weights(
    y_train: np.ndarray,
    ch_train: np.ndarray,
    num_classes: int,
    class_power: float = 1.0,
    change_power: float = 1.0,
    max_clip: float = 10.0,
    change_oversample_factor: float = 1.0,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Adaptive sampling weights: w_i = w_change(i) * w_class(y_i).

    在原有 class/change 频率加权基础上，额外让 change_oversample_factor
    只作用于变化样本（ch_train == 1）。
    """
    y_train = y_train.astype(np.int64)
    ch_train = ch_train.astype(np.int64)

    valid = y_train >= 0
    cls_counts = np.bincount(y_train[valid], minlength=num_classes).astype(np.float64)
    cls_counts = np.maximum(cls_counts, 1.0)
    total_cls = cls_counts.sum()
    w_class_table = (total_cls / cls_counts) ** float(class_power)
    w_class_table = w_class_table / np.mean(w_class_table)
    w_class = w_class_table[np.clip(y_train, 0, num_classes - 1)]
    w_class[~valid] = 1.0

    ch_counts = np.bincount(ch_train, minlength=2).astype(np.float64)
    ch_counts = np.maximum(ch_counts, 1.0)
    total_ch = ch_counts.sum()
    w_change_table = (total_ch / ch_counts) ** float(change_power)
    w_change_table = w_change_table / np.mean(w_change_table)

    # 让 change_oversample_factor 真正生效：只增强变化样本
    cof = max(float(change_oversample_factor), 1.0)
    w_change_table[1] *= cof

    w_change = w_change_table[np.clip(ch_train, 0, 1)]

    w = w_class * w_change
    w = w / np.mean(w)
    if max_clip is not None and max_clip > 0:
        w = np.clip(w, 1e-8, float(max_clip))
        w = w / np.mean(w)

    return w.astype(np.float32), w_class_table.astype(np.float32), w_change_table.astype(np.float32)


def _write_center_mask_tif(mask: np.ndarray, ref_profile: dict, out_path: str):
    prof = ref_profile.copy()
    prof.update(dtype="uint8", count=1)
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    with rasterio.open(out_path, "w", **prof) as dst:
        dst.write(mask.astype(np.uint8), 1)


# ------------------------------------------------------------------------
# Dataset (same data protocol, simplified target usage)
# ------------------------------------------------------------------------
class MemoryRasterDataset(torch.utils.data.Dataset):
    def __init__(
        self,
        root_dir: str,
        lucc_dir: str,
        driver_names: List[str],
        driver_input_years: List[int],
        target_year: int,
        base_year_for_change: int,
        num_land_classes: int,
        patch_size: int = 21,
        stride: int = 5,
        class_offset: int = 1,
        lucc_mode: str = "auto",
        valid_mask_path: Optional[str] = None,
        valid_mask_ref_year: Optional[int] = None,
        static_dir: Optional[str] = None,
        static_names: Tuple[str, ...] = ("dem", "slope", "aspect"),
    ):
        super().__init__()
        self.root_dir = root_dir
        self.lucc_dir = lucc_dir
        self.driver_names = list(driver_names)
        self.driver_years = list(driver_input_years)
        self.target_year = int(target_year)
        self.base_year_for_change = int(base_year_for_change)

        self.num_driver_channels = len(self.driver_names)
        self.num_land_channels = int(num_land_classes)
        self.patch_size = int(patch_size)
        self.stride = int(stride)
        self.class_offset = int(class_offset)
        self.lucc_mode = lucc_mode
        self.lucc_mode_resolved = None
        self.valid_mask_path = valid_mask_path
        self.valid_mask_ref_year = valid_mask_ref_year
        self.static_dir = static_dir
        self.static_names = tuple(static_names)
        self.static_arrays: Optional[Dict[str, np.ndarray]] = None
        self.static_dim = 0

        self.driver_cache: Dict[int, Dict[str, np.ndarray]] = {}
        self.lucc_cache: Dict[int, np.ndarray] = {}

        print(f"[Dataset] Loading rasters into RAM | target={self.target_year} ...")
        self._load_drivers_into_memory()
        self.height, self.width = self._get_ref_shape()
        self._load_lucc_into_memory()
        self._load_static_into_memory()

        self.valid_mask = self._build_valid_mask()
        self.windows: List[Tuple[int, int]] = []
        self._build_windows()
        print(f"[Dataset] windows={len(self.windows)} | patch={self.patch_size} stride={self.stride}")

        self.center_target = self._compute_center_class_map(self.target_year)
        self.center_base = self._compute_center_class_map(self.base_year_for_change)
        self.center_change = (self.center_target != self.center_base) & (self.center_target >= 0) & (self.center_base >= 0)

    def _get_ref_shape(self) -> Tuple[int, int]:
        y0 = self.driver_years[0]
        d0 = self.driver_names[0]
        arr = self.driver_cache[y0][d0]
        return arr.shape

    def _load_drivers_into_memory(self) -> None:
        for y in sorted(set(self.driver_years)):
            self.driver_cache[y] = {}
            for d_name in self.driver_names:
                path = os.path.join(self.root_dir, d_name, f"{d_name}_{y}.tif")
                if not os.path.exists(path):
                    raise FileNotFoundError(f"Driver not found: {path}")
                with rasterio.open(path) as src:
                    data = src.read(1).astype(np.float32)
                    nodata = src.nodata
                invalid = ~np.isfinite(data) | (data < -9000)
                if nodata is not None:
                    invalid |= (data == nodata)
                data[invalid] = np.nan
                self.driver_cache[y][d_name] = data

    def _load_lucc_into_memory(self) -> None:
        years = sorted(set([self.target_year, self.base_year_for_change]))
        if self.lucc_mode not in ("auto", "onehot", "index"):
            raise ValueError("lucc_mode must be one of {auto,onehot,index}")

        probe_path = _find_lucc_path(self.lucc_dir, years[0])
        detected = _detect_lucc_mode_from_file(probe_path)
        self.lucc_mode_resolved = detected if self.lucc_mode == "auto" else self.lucc_mode

        for y in years:
            path = _find_lucc_path(self.lucc_dir, y)
            mode_y = _detect_lucc_mode_from_file(path)
            if mode_y != self.lucc_mode_resolved:
                raise ValueError(f"LUCC mode mismatch: year={y} file_mode={mode_y} expected={self.lucc_mode_resolved}")
            with rasterio.open(path) as src:
                nodata = src.nodata
                if self.lucc_mode_resolved == "onehot":
                    arr = src.read().astype(np.float32)
                    arr[~np.isfinite(arr)] = 0.0
                    arr[arr < 0] = 0.0
                    if arr.shape[0] != self.num_land_channels:
                        raise ValueError(
                            f"Onehot bands mismatch: got {arr.shape[0]}, expected {self.num_land_channels} ({path})")
                    self.lucc_cache[y] = arr
                else:
                    idx = src.read(1).astype(np.int16)
                    invalid = np.zeros(idx.shape, dtype=bool)
                    if nodata is not None:
                        invalid |= (idx == nodata)
                    invalid |= (idx < self.class_offset) | (idx > (self.class_offset + self.num_land_channels - 1))
                    idx[invalid] = -1
                    ok = idx >= 0
                    idx[ok] = idx[ok] - self.class_offset
                    self.lucc_cache[y] = idx

    def _load_static_into_memory(self) -> None:
        if not self.static_dir:
            self.static_arrays = None
            self.static_dim = 0
            return
        arrays: Dict[str, np.ndarray] = {}
        for name in self.static_names:
            path = os.path.join(self.static_dir, f"{name}.tif")
            if not os.path.exists(path):
                raise FileNotFoundError(f"Static raster not found: {path}")
            with rasterio.open(path) as src:
                arr = src.read(1).astype(np.float32)
                nodata = src.nodata
            invalid = ~np.isfinite(arr)
            if nodata is not None:
                invalid |= (arr == nodata)
            arr[invalid] = np.nan
            arrays[name] = arr
        if "aspect" in arrays:
            asp = arrays["aspect"]
            rad = np.deg2rad(asp)
            arrays["aspect_sin"] = np.sin(rad).astype(np.float32)
            arrays["aspect_cos"] = np.cos(rad).astype(np.float32)
            arrays.pop("aspect", None)
        self.static_arrays = arrays
        self.static_dim = len(self._static_feature_order())

    def _static_feature_order(self) -> List[str]:
        if not self.static_arrays:
            return []
        order = []
        for k in ("dem", "slope", "aspect_sin", "aspect_cos"):
            if k in self.static_arrays:
                order.append(k)
        for k in sorted(self.static_arrays.keys()):
            if k not in order:
                order.append(k)
        return order

    def _build_valid_mask(self) -> np.ndarray:
        if self.valid_mask_path:
            return _read_mask(self.valid_mask_path, (self.height, self.width))
        if self.valid_mask_ref_year is not None:
            y = int(self.valid_mask_ref_year)
            if self.lucc_mode_resolved == "onehot":
                return np.sum(self.lucc_cache[y], axis=0) > 0
            return self.lucc_cache[y] >= 0

        y = self.base_year_for_change
        if self.lucc_mode_resolved == "onehot":
            return np.sum(self.lucc_cache[y], axis=0) > 0
        return self.lucc_cache[y] >= 0

    def _build_windows(self) -> None:
        ps = self.patch_size
        half = ps // 2
        for top in range(0, self.height - ps + 1, self.stride):
            for left in range(0, self.width - ps + 1, self.stride):
                ct, cl = top + half, left + half
                if self.valid_mask[ct, cl]:
                    self.windows.append((top, left))

    def _get_lucc_patch_onehot(self, year: int, top: int, left: int) -> np.ndarray:
        h = self.patch_size
        if self.lucc_mode_resolved == "onehot":
            return self.lucc_cache[year][:, top:top + h, left:left + h]
        idx_patch = self.lucc_cache[year][top:top + h, left:left + h]
        out = np.zeros((self.num_land_channels, h, h), dtype=np.float32)
        for c in range(self.num_land_channels):
            out[c] = (idx_patch == c).astype(np.float32)
        return out

    def _get_lucc_center_class(self, year: int, top: int, left: int) -> int:
        half = self.patch_size // 2
        r, c = top + half, left + half
        if self.lucc_mode_resolved == "onehot":
            vec = self.lucc_cache[year][:, r, c]
            if np.sum(vec) <= 0:
                return -1
            return int(np.argmax(vec))
        val = int(self.lucc_cache[year][r, c])
        return val if val >= 0 else -1

    def _get_static_patch(self, top: int, left: int) -> Optional[np.ndarray]:
        """
        Return static patch with shape (C_static, patch_size, patch_size).
        """
        if not self.static_arrays or self.static_dim <= 0:
            return None

        h = self.patch_size
        feats = []
        for name in self._static_feature_order():
            arr = self.static_arrays[name][top:top + h, left:left + h].astype(np.float32)
            arr = np.nan_to_num(arr, nan=0.0, posinf=0.0, neginf=0.0)
            feats.append(arr)

        if not feats:
            return None
        return np.stack(feats, axis=0).astype(np.float32)

    def _compute_center_class_map(self, year: int) -> np.ndarray:
        arr = np.full((len(self.windows),), -1, dtype=np.int16)
        for i, (top, left) in enumerate(self.windows):
            arr[i] = self._get_lucc_center_class(year, top, left)
        return arr

    def __len__(self) -> int:
        return len(self.windows)

    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        top, left = self.windows[idx]
        ps = self.patch_size

        # drivers_seq: (C_drv, T, H, W)
        d_seq_list = []
        for y in self.driver_years:
            yr_drivers = []
            for name in self.driver_names:
                patch = self.driver_cache[y][name][top:top + ps, left:left + ps].astype(np.float32)
                patch = np.nan_to_num(patch, nan=0.0, posinf=0.0, neginf=0.0)
                yr_drivers.append(patch)
            d_seq_list.append(np.stack(yr_drivers, axis=0))
        d_seq = np.stack(d_seq_list, axis=0)
        d_seq = torch.from_numpy(d_seq).permute(1, 0, 2, 3).float()  # (C_drv, T, H, W)

        # target patch supervision
        t_oh = self._get_lucc_patch_onehot(self.target_year, top, left)  # (C_lu, H, W)
        t_cls = torch.from_numpy(np.argmax(t_oh, axis=0).astype(np.int64))  # (H, W)
        t_mask = torch.from_numpy((np.sum(t_oh, axis=0) > 0).astype(np.uint8))  # (H, W)

        # center-level labels / diagnostics
        center_target = int(self._get_lucc_center_class(self.target_year, top, left))
        center_base = int(self._get_lucc_center_class(self.base_year_for_change, top, left))
        center_change = int((center_target >= 0) and (center_base >= 0) and (center_target != center_base))

        out = {
            "drivers_seq": d_seq,
            "target_cls": t_cls,
            "target_mask": t_mask,
            "top": torch.tensor(top, dtype=torch.int32),
            "left": torch.tensor(left, dtype=torch.int32),
            "center_base": torch.tensor(center_base, dtype=torch.long),
            "center_target": torch.tensor(center_target, dtype=torch.long),
            "center_change": torch.tensor(center_change, dtype=torch.long),
        }

        static_patch = self._get_static_patch(top, left)
        if static_patch is not None:
            out["static_patch"] = torch.from_numpy(static_patch)

        return out


# ------------------------------------------------------------------------
# Metrics
# ------------------------------------------------------------------------
def per_class_f1_from_conf(conf: np.ndarray) -> Tuple[np.ndarray, float]:
    K = conf.shape[0]
    f1 = np.zeros(K, dtype=np.float64)
    for k in range(K):
        tp = conf[k, k]
        fp = conf[:, k].sum() - tp
        fn = conf[k, :].sum() - tp
        denom = 2 * tp + fp + fn
        f1[k] = (2 * tp / denom) if denom > 0 else 0.0
    return f1, float(np.mean(f1))


def change_binary_f1(y_true_change: np.ndarray, y_pred_change: np.ndarray) -> float:
    tp = np.sum((y_true_change == 1) & (y_pred_change == 1))
    fp = np.sum((y_true_change == 0) & (y_pred_change == 1))
    fn = np.sum((y_true_change == 1) & (y_pred_change == 0))
    denom = 2 * tp + fp + fn
    return float((2 * tp / denom) if denom > 0 else 0.0)


def fom_from_triplets(prev: np.ndarray, tru: np.ndarray, prd: np.ndarray) -> Dict[str, float]:
    valid = (prev >= 0) & (tru >= 0) & (prd >= 0)
    prev = prev[valid]
    tru = tru[valid]
    prd = prd[valid]
    changed = prev != tru
    pred_changed = prev != prd
    hits = np.sum(changed & pred_changed & (prd == tru))
    wrong_change = np.sum(changed & pred_changed & (prd != tru))
    misses = np.sum(changed & (~pred_changed))
    false_alarm = np.sum((~changed) & pred_changed)
    denom = hits + wrong_change + misses + false_alarm
    fom = hits / denom if denom > 0 else 0.0
    return {
        "FoM": float(fom),
        "hits": int(hits),
        "wrong_change": int(wrong_change),
        "misses": int(misses),
        "false_alarm": int(false_alarm),
    }


def eval_center_metrics(pred: np.ndarray, y_true: np.ndarray, prev: np.ndarray, num_classes: int) -> Dict[str, float]:
    valid = (y_true >= 0) & (pred >= 0)
    yv = y_true[valid].astype(np.int64)
    pv = pred[valid].astype(np.int64)
    prev_v = prev[valid].astype(np.int64)

    conf = np.zeros((num_classes, num_classes), dtype=np.int64)
    for t, p in zip(yv, pv):
        conf[t, p] += 1

    oa = float((yv == pv).mean()) if len(yv) > 0 else 0.0
    total = conf.sum()
    po = np.trace(conf) / total if total > 0 else 0.0
    pe = (conf.sum(axis=0) * conf.sum(axis=1)).sum() / (total * total) if total > 0 else 0.0
    kappa = float((po - pe) / (1 - pe)) if (1 - pe) > 1e-12 else 0.0

    per_f1, macro_f1 = per_class_f1_from_conf(conf)
    true_change = (yv != prev_v).astype(np.uint8)
    pred_change = (pv != prev_v).astype(np.uint8)
    change_f1 = change_binary_f1(true_change, pred_change)
    fom = fom_from_triplets(prev_v, yv, pv)

    metrics = {
        "OA": oa,
        "Kappa": kappa,
        "MacroF1": float(macro_f1),
        "changeF1": float(change_f1),
        "FoM": float(fom["FoM"]),
    }
    for i, v in enumerate(per_f1.tolist(), start=1):
        metrics[f"F1_class_{i}"] = float(v)
    metrics.update({
        "hits": fom["hits"],
        "wrong_change": fom["wrong_change"],
        "misses": fom["misses"],
        "false_alarm": fom["false_alarm"],
    })
    return metrics


# ------------------------------------------------------------------------
# Validation / test
# ------------------------------------------------------------------------
@torch.no_grad()
def evaluate(model, loader, device, num_classes: int) -> Dict[str, float]:
    model.eval()
    pred_all, y_all, prev_all = [], [], []
    losses = []

    for batch in loader:
        drivers = batch["drivers_seq"].to(device, non_blocking=True)
        target = batch["target_cls"].to(device, non_blocking=True)
        mask = batch["target_mask"].to(device, non_blocking=True)

        static_patch = batch.get("static_patch", None)
        if static_patch is not None:
            static_patch = static_patch.to(device, non_blocking=True)

        out = model(
            drivers_seq=drivers,
            static_patch=static_patch,
            return_attn=False,
        )
        logits = out["pot_logits"].squeeze(-1).squeeze(-1)  # (B,K)

        c = target.shape[-1] // 2
        y = target[:, c, c]
        m = mask[:, c, c].bool()
        prev = batch["center_base"].cpu().numpy().astype(np.int16)

        valid = m & (y >= 0)
        if valid.any():
            logits_v = logits[valid]
            y_v = y[valid]
            loss = F.cross_entropy(logits_v, y_v)
            losses.append(float(loss.detach().cpu().item()))

            pred_v = torch.argmax(logits_v, dim=1).detach().cpu().numpy().astype(np.int16)
            y_v_np = y_v.detach().cpu().numpy().astype(np.int16)
            valid_np = valid.detach().cpu().numpy()

            pred_all.append(pred_v)
            y_all.append(y_v_np)
            prev_all.append(prev[valid_np])

    if len(pred_all) == 0:
        return {
            "loss": 0.0,
            "OA": 0.0,
            "Kappa": 0.0,
            "MacroF1": 0.0,
            "changeF1": 0.0,
            "FoM": 0.0,
        }

    pred_all = np.concatenate(pred_all)
    y_all = np.concatenate(y_all)
    prev_all = np.concatenate(prev_all)

    metrics = eval_center_metrics(pred_all, y_all, prev_all, num_classes)
    metrics["loss"] = float(np.mean(losses)) if losses else 0.0
    return metrics


# ------------------------------------------------------------------------
# Main
# ------------------------------------------------------------------------
def main():
    parser = argparse.ArgumentParser()

    # I/O
    parser.add_argument("--root_dir", type=str, default="../data/drivers/dynamic")
    parser.add_argument("--lucc_dir", type=str, default="../data/lucc")
    parser.add_argument("--static_dir", type=str, default="../data/drivers/static")
    parser.add_argument("--ckpt_out", type=str, default="ckpts/best_model_driver_only_3dcnn.pth")
    parser.add_argument("--out_dir", type=str, default="train_outputs_driver_only_3dcnn")

    # LU config
    parser.add_argument("--num_land_classes", type=int, default=6)
    parser.add_argument("--lucc_mode", type=str, choices=["auto", "onehot", "index"], default="index")
    parser.add_argument("--class_offset", type=int, default=1)

    # Patches
    parser.add_argument("--patch_size", type=int, default=11)
    parser.add_argument("--stride", type=int, default=4)

    # Split
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument(
        "--split_json",
        type=str,
        default=None,
        help="Path to shared block split json. If provided, use it instead of internal random spatial block split."
    )

    # Mask
    parser.add_argument("--valid_mask", type=str, default="../data/lucc/mask_valid.tif")

    # Static
    parser.add_argument("--static_names", type=str, nargs='+', default=["dem", "slope", "aspect"])

    # Training
    parser.add_argument("--batch_size", type=int, default=256)
    parser.add_argument("--epochs", type=int, default=30)
    parser.add_argument("--lr", type=float, default=1e-4)
    parser.add_argument("--weight_decay", type=float, default=1.5e-3)
    parser.add_argument("--dropout_rate", type=float, default=0.25)
    parser.add_argument("--embed_dim", type=int, default=128)
    parser.add_argument("--change_oversample_factor", type=float, default=1.75)
    parser.add_argument("--lr_patience", type=int, default=2)
    parser.add_argument("--lr_factor", type=float, default=0.5)
    parser.add_argument("--min_lr", type=float, default=1e-6)
    parser.add_argument("--use_class_weights", action="store_true")
    parser.add_argument("--sampler_class_power", type=float, default=0.10)
    parser.add_argument("--sampler_change_power", type=float, default=0.45)
    parser.add_argument("--sampler_max_clip", type=float, default=2.0)

    args = parser.parse_args()

    args.root_dir = _resolve_path(args.root_dir)
    args.lucc_dir = _resolve_path(args.lucc_dir)
    args.static_dir = _resolve_path(args.static_dir) if args.static_dir else None
    args.out_dir = _resolve_path(args.out_dir)
    os.makedirs(args.out_dir, exist_ok=True)
    if args.valid_mask:
        args.valid_mask = _resolve_path(args.valid_mask)

    if args.split_json:
        args.split_json = _resolve_path(args.split_json)

    os.makedirs(os.path.dirname(args.ckpt_out), exist_ok=True)
    set_global_reproducibility(args.seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    args.patch_size = _ensure_odd_patch_size(args.patch_size)

    # Scheme A tasks
    task1 = dict(driver_years=[2000, 2005, 2010], target_year=2010, base_year=2005)
    task2 = dict(driver_years=[2005, 2010, 2015], target_year=2015, base_year=2010)

    driver_names = detect_driver_names(args.root_dir, years=[2000, 2005, 2010, 2015])
    if not driver_names:
        raise RuntimeError("No dynamic drivers detected.")
    print(f"Drivers(dynamic): {driver_names}")

    valid_mask_ref_year = 2015 if args.valid_mask is None else None

    ds1 = MemoryRasterDataset(
        root_dir=args.root_dir, lucc_dir=args.lucc_dir,
        driver_names=list(driver_names),
        driver_input_years=task1["driver_years"],
        target_year=task1["target_year"],
        base_year_for_change=task1["base_year"],
        num_land_classes=args.num_land_classes,
        patch_size=args.patch_size, stride=args.stride,
        class_offset=args.class_offset, lucc_mode=args.lucc_mode,
        valid_mask_path=args.valid_mask, valid_mask_ref_year=valid_mask_ref_year,
        static_dir=args.static_dir, static_names=tuple(args.static_names)
    )
    ds2 = MemoryRasterDataset(
        root_dir=args.root_dir, lucc_dir=args.lucc_dir,
        driver_names=list(driver_names),
        driver_input_years=task2["driver_years"],
        target_year=task2["target_year"],
        base_year_for_change=task2["base_year"],
        num_land_classes=args.num_land_classes,
        patch_size=args.patch_size, stride=args.stride,
        class_offset=args.class_offset, lucc_mode=args.lucc_mode,
        valid_mask_path=args.valid_mask, valid_mask_ref_year=valid_mask_ref_year,
        static_dir=args.static_dir, static_names=tuple(args.static_names)
    )

    if len(ds1.windows) != len(ds2.windows) or ds1.windows[:10] != ds2.windows[:10]:
        raise RuntimeError("Task windows mismatch between ds1 and ds2. Provide a consistent valid_mask to fix.")

    windows = ds1.windows
    split_obj = _load_shared_block_split(args.split_json)
    train_idx, val_idx, test_idx = _split_indices_from_shared_blocks_windows(
        windows=windows,
        patch_size=args.patch_size,
        split_obj=split_obj,
    )
    print(f"[Split] using shared split json: {args.split_json}")

    print(f"Split(spatial_blocks): train={len(train_idx)} val={len(val_idx)} test={len(test_idx)}")

    # export split masks
    ref_path = _find_lucc_path(args.lucc_dir, task2["target_year"])
    with rasterio.open(ref_path) as src:
        ref_profile = src.profile.copy()
        H, W = src.height, src.width
    center = args.patch_size // 2
    train_mask = np.zeros((H, W), dtype=np.uint8)
    val_mask = np.zeros((H, W), dtype=np.uint8)
    test_mask = np.zeros((H, W), dtype=np.uint8)
    for i in train_idx:
        top, left = windows[i]
        train_mask[top + center, left + center] = 1
    for i in val_idx:
        top, left = windows[i]
        val_mask[top + center, left + center] = 1
    for i in test_idx:
        top, left = windows[i]
        test_mask[top + center, left + center] = 1
    split_dir = os.path.join(args.out_dir, "split_masks")
    os.makedirs(split_dir, exist_ok=True)
    _write_center_mask_tif(train_mask, ref_profile, os.path.join(split_dir, "train_mask_centers.tif"))
    _write_center_mask_tif(val_mask, ref_profile, os.path.join(split_dir, "val_mask_centers.tif"))
    _write_center_mask_tif(test_mask, ref_profile, os.path.join(split_dir, "test_mask_centers.tif"))

    train_set = ConcatDataset([Subset(ds1, train_idx), Subset(ds2, train_idx)])
    val_set = ConcatDataset([Subset(ds1, val_idx), Subset(ds2, val_idx)])
    test_set = ConcatDataset([Subset(ds1, test_idx), Subset(ds2, test_idx)])

    # Optional class weights from train center targets
    class_weights = None
    if args.use_class_weights:
        y_train = np.concatenate([ds1.center_target[train_idx], ds2.center_target[train_idx]], axis=0)
        valid = y_train >= 0
        counts = np.bincount(y_train[valid].astype(np.int64), minlength=args.num_land_classes).astype(np.float64)
        w = counts.sum() / np.maximum(counts, 1.0)
        w = w / w.mean()
        class_weights = torch.tensor(w.astype(np.float32), device=device)
        print(f"[ClassWeights] counts={counts.astype(np.int64).tolist()}")
        print(f"[ClassWeights] weights={np.round(w, 4).tolist()}")

    # Adaptive sampling: w_i = w_change(i) * w_class(y_i)
    y_train_sampler = np.concatenate([ds1.center_target[train_idx], ds2.center_target[train_idx]], axis=0).astype(np.int64)
    ch_train = np.concatenate([ds1.center_change[train_idx], ds2.center_change[train_idx]], axis=0).astype(np.int64)
    samp_w, w_class_table, w_change_table = _compute_adaptive_sample_weights(
        y_train=y_train_sampler,
        ch_train=ch_train,
        num_classes=args.num_land_classes,
        class_power=float(args.sampler_class_power),
        change_power=float(args.sampler_change_power),
        max_clip=float(args.sampler_max_clip),
        change_oversample_factor=float(args.change_oversample_factor),
    )
    print(
        f"[AdaptiveSampler] change_oversample_factor={float(args.change_oversample_factor):.3f} | "
        f"change_table={np.round(w_change_table, 4).tolist()} (0=no-change,1=change)"
    )
    print(f"[AdaptiveSampler] class_table={np.round(w_class_table, 4).tolist()}")
    sampler_generator = torch.Generator()
    sampler_generator.manual_seed(args.seed)

    sampler = WeightedRandomSampler(
        torch.tensor(samp_w, dtype=torch.double),
        num_samples=len(samp_w),
        replacement=True,
        generator=sampler_generator,
    )

    loader_generator = torch.Generator()
    loader_generator.manual_seed(args.seed)

    train_loader = DataLoader(
        train_set,
        batch_size=args.batch_size,
        sampler=sampler,
        num_workers=0,
        pin_memory=True,
        worker_init_fn=seed_worker,
        generator=loader_generator,
    )

    val_loader = DataLoader(
        val_set,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=0,
        pin_memory=True,
        worker_init_fn=seed_worker,
        generator=loader_generator,
    )

    test_loader = DataLoader(
        test_set,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=0,
        pin_memory=True,
        worker_init_fn=seed_worker,
        generator=loader_generator,
    )

    model = build_model(
        num_driver_channels=len(driver_names),
        num_classes=args.num_land_classes,
        dropout_rate=args.dropout_rate,
        num_static_channels=ds1.static_dim,
        static_feat_dim=32,
        embed_dim=args.embed_dim,
    ).to(device)

    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, mode="max", factor=float(args.lr_factor), patience=int(args.lr_patience), min_lr=float(args.min_lr)
    )

    best_score = -1e9
    best_ckpt = None

    print("Starting Training Driver-only 3D-CNN...")
    for epoch in range(1, args.epochs + 1):
        model.train()
        train_losses = []
        pbar = tqdm(train_loader, desc=f"Epoch {epoch}/{args.epochs}", leave=False)
        for batch in pbar:
            drivers = batch["drivers_seq"].to(device, non_blocking=True)
            target = batch["target_cls"].to(device, non_blocking=True)
            mask = batch["target_mask"].to(device, non_blocking=True)

            static_patch = batch.get("static_patch", None)
            if static_patch is not None:
                static_patch = static_patch.to(device, non_blocking=True)

            out = model(
                drivers_seq=drivers,
                static_patch=static_patch,
                return_attn=False,
            )
            logits = out["pot_logits"].squeeze(-1).squeeze(-1)  # (B,K)

            c = target.shape[-1] // 2
            y = target[:, c, c]
            m = mask[:, c, c].bool()
            valid = m & (y >= 0)
            if not valid.any():
                continue
            logits_v = logits[valid]
            y_v = y[valid]
            loss = F.cross_entropy(logits_v, y_v, weight=class_weights)

            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            optimizer.step()

            train_losses.append(float(loss.detach().cpu().item()))
            pbar.set_postfix(loss=f"{np.mean(train_losses):.4f}")

        val_metrics = evaluate(model, val_loader, device, args.num_land_classes)

        # Best-model score based on OA + Kappa + FoM
        # Suggested weights:
        #   OA     : 0.30
        #   Kappa  : 0.35
        #   FoM    : 0.35
        val_score = (
                0.30 * float(val_metrics["OA"]) +
                0.30 * float(val_metrics["Kappa"]) +
                0.40 * float(val_metrics["FoM"])
        )

        scheduler.step(val_score)

        lr_now = optimizer.param_groups[0]["lr"]
        tr_loss = float(np.mean(train_losses)) if train_losses else 0.0
        print(
            f"[Epoch {epoch:03d}] train_loss={tr_loss:.4f} lr={lr_now:.6f} | "
            f"val_OA={val_metrics['OA']:.4f} val_Kappa={val_metrics['Kappa']:.4f} "
            f"val_MacroF1={val_metrics['MacroF1']:.4f} val_changeF1={val_metrics['changeF1']:.4f} "
            f"val_FoM={val_metrics['FoM']:.4f} val_score={val_score:.4f}"
        )

        if val_score > best_score:
            best_score = val_score
            best_ckpt = {
                "epoch": epoch,
                "model_state": model.state_dict(),
                "optimizer_state": optimizer.state_dict(),
                "best_score": best_score,
                "val_metrics": val_metrics,
                "driver_names": list(driver_names),
                "static_dim": ds1.static_dim,
                "num_static_channels": ds1.static_dim,
                "num_land_classes": args.num_land_classes,
                "args": vars(args),
            }
            torch.save(best_ckpt, args.ckpt_out)
            print(f"[Best] saved -> {args.ckpt_out} | best_score={best_score:.4f}")

    print("Training finished.")
    if best_ckpt is None:
        raise RuntimeError("No valid checkpoint was saved. Please check data/labels.")

    # Final test using best ckpt
    model.load_state_dict(torch.load(args.ckpt_out, map_location=device)["model_state"])
    test_metrics = evaluate(model, test_loader, device, args.num_land_classes)
    print("\n========== Test Metrics ==========")
    for k, v in test_metrics.items():
        if isinstance(v, float):
            print(f"{k}: {v:.4f}")
        else:
            print(f"{k}: {v}")

    # Save test metrics
    metrics_path = os.path.join(args.out_dir, "metrics_test.txt")
    with open(metrics_path, "w", encoding="utf-8") as f:
        for k, v in test_metrics.items():
            f.write(f"{k}: {v}\n")
    print(f"[Metrics] saved -> {metrics_path}")


if __name__ == "__main__":
    main()
